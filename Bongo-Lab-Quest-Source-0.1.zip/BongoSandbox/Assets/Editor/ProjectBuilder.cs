using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEditor.Build;
using UnityEngine;
using Unity.Netcode;
using Unity.Netcode.Components;
using Unity.Netcode.Transports.UTP;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;
using UnityEngine.XR.OpenXR.Features.Interactions;
using UnityEngine.XR.OpenXR.Features.OculusQuestSupport;

namespace BongoSandbox.Editor
{
    [InitializeOnLoad]
    public static class ProjectBuilder
    {
        const string Scene="Assets/Scenes/Sandbox.unity";
        static ProjectBuilder()
        {
            EditorApplication.delayCall+=()=>
            {
                if(!Application.isBatchMode && !File.Exists(Scene) && !EditorApplication.isPlayingOrWillChangePlaymode) Create();
            };
        }

        [MenuItem("Bongo Lab/1 - Generate playground")]
        public static void Create()
        {
            Directory.CreateDirectory("Assets/Prefabs");Directory.CreateDirectory("Assets/Scenes");
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var player=new GameObject("Player");
            player.AddComponent<NetworkObject>();player.AddComponent<Avatar>();
            var playerAsset=PrefabUtility.SaveAsPrefabAsset(player,"Assets/Prefabs/Player.prefab");
            UnityEngine.Object.DestroyImmediate(player);
            var bongo=Thing("Bongo",0);
            var block=Thing("Block",1);
            var ball=Thing("Ball",2);
            var room=new GameObject("Bongo Lab").AddComponent<Room>();
            room.playerPrefab=playerAsset;room.bongoPrefab=bongo;room.cubePrefab=block;room.ballPrefab=ball;
            EditorSceneManager.SaveScene(scene,Scene);
            EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(Scene,true)};
            PlayerSettings.companyName="Nolan";
            PlayerSettings.productName="Bongo Lab";
            PlayerSettings.bundleVersion="0.1.0";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android,"com.nolan.bongolab");
            PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel32;
            PlayerSettings.Android.targetSdkVersion=AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
            PlayerSettings.Android.forceInternetPermission=true;
            PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
            PlayerSettings.colorSpace=ColorSpace.Linear;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android,false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android,new[]{UnityEngine.Rendering.GraphicsDeviceType.OpenGLES3});
            QualitySettings.vSyncCount=0;QualitySettings.antiAliasing=4;
            SetInputSystem();
            AssetDatabase.SaveAssets();
            Debug.Log("BONGO_PROJECT_GENERATED");
        }

        static GameObject Thing(string name,int kind)
        {
            var go=new GameObject(name);
            go.AddComponent<NetworkObject>();
            var rb=go.AddComponent<Rigidbody>();rb.mass=kind==0?4:1;
            rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
            rb.interpolation=RigidbodyInterpolation.Interpolate;
            if(kind==0)
            {
                var c=go.AddComponent<BoxCollider>();c.size=new Vector3(1,.95f,.45f);c.center=new Vector3(0,.15f,0);
                rb.constraints=RigidbodyConstraints.FreezeRotation;
            }
            else if(kind==1) go.AddComponent<BoxCollider>().size=Vector3.one*.5f;
            else go.AddComponent<SphereCollider>().radius=.25f;
            go.AddComponent<NetworkTransform>();
            go.AddComponent<SharedThing>().kind=kind;
            var asset=PrefabUtility.SaveAsPrefabAsset(go,"Assets/Prefabs/"+name+".prefab");
            UnityEngine.Object.DestroyImmediate(go);
            return asset;
        }

        static void SetInputSystem()
        {
            var settings=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset")[0]);
            var active=settings.FindProperty("activeInputHandler");
            if(active!=null){active.intValue=1;settings.ApplyModifiedPropertiesWithoutUndo();}
        }

        [MenuItem("Bongo Lab/2 - Configure Quest OpenXR")]
        public static void ConfigureXR()
        {
            var perTarget=XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(BuildTargetGroup.Android);
            if(perTarget==null)
            {
                EditorApplication.ExecuteMenuItem("Edit/Project Settings...");
                throw new InvalidOperationException("Open Project Settings > XR Plug-in Management, enable OpenXR in Android, then run this command again.");
            }
            if(perTarget.Manager==null)
            {
                var manager=ScriptableObject.CreateInstance<XRManagerSettings>();
                AssetDatabase.AddObjectToAsset(manager,perTarget);
                perTarget.Manager=manager;
            }
            if(!XRPackageMetadataStore.AssignLoader(perTarget.Manager,"UnityEngine.XR.OpenXR.OpenXRLoader",BuildTargetGroup.Android))
                throw new InvalidOperationException("OpenXR could not be assigned. Enable it in Android XR Plug-in Management.");
            perTarget.InitManagerOnStart=true;
            var xr=OpenXRSettings.GetSettingsForBuildTargetGroup(BuildTargetGroup.Android);
            if(xr==null) throw new InvalidOperationException("OpenXR Android settings not created. Reopen Project Settings and retry.");
            foreach(var feature in xr.GetFeatures<OpenXRFeature>())
                if(feature is OculusTouchControllerProfile || feature is OculusQuestFeature) feature.enabled=true;
            EditorUtility.SetDirty(xr);EditorUtility.SetDirty(perTarget);
            AssetDatabase.SaveAssets();
            Debug.Log("Quest OpenXR configured. Run OpenXR Project Validation before building.");
        }

        [MenuItem("Bongo Lab/3 - Build Quest APK")]
        public static void BuildQuest()
        {
            if(!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android,BuildTarget.Android))
                throw new InvalidOperationException("Install Android Build Support, SDK/NDK and OpenJDK for Unity 6000.0.85f1 through Unity Hub.");
            if(!File.Exists(Scene)) Create();
            ConfigureXR();
            if(!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android,BuildTarget.Android))
                throw new InvalidOperationException("Could not switch build target to Android. Wait for compilation and retry.");
            Directory.CreateDirectory("Builds");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{Scene},locationPathName="Builds/BongoLab.apk",target=BuildTarget.Android,options=BuildOptions.Development});
            if(report.summary.result!=BuildResult.Succeeded) throw new Exception("APK build failed: "+report.summary.result);
            Debug.Log("BONGO_APK_BUILT: "+Path.GetFullPath("Builds/BongoLab.apk"));
        }
    }
}
