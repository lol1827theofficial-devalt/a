using UnityEngine;
using Unity.Netcode;

namespace BongoSandbox
{
    public sealed class Avatar : NetworkBehaviour
    {
        public static Avatar Local;
        readonly NetworkVariable<Vector3> head = new();
        readonly NetworkVariable<Quaternion> headRotation = new(Quaternion.identity);
        readonly NetworkVariable<Vector3> left = new();
        readonly NetworkVariable<Vector3> right = new();
        Transform headVisual, leftVisual, rightVisual, body;
        float nextPose, nextAction;
        public Vector3 HeadPosition => head.Value;
        public Vector3 Hand(bool isLeft) => isLeft ? left.Value : right.Value;

        public override void OnNetworkSpawn()
        {
            if(IsOwner) Local = this;
            var color = OwnerClientId == 0 ? new Color(.3f,.8f,1) : new Color(1,.65f,.2f);
            headVisual=Shapes.Make("Ape head",PrimitiveType.Sphere,transform,Vector3.zero,Vector3.one*.32f,color,false).transform;
            leftVisual=Shapes.Make("Left hand",PrimitiveType.Sphere,transform,Vector3.zero,Vector3.one*.15f,color,false).transform;
            rightVisual=Shapes.Make("Right hand",PrimitiveType.Sphere,transform,Vector3.zero,Vector3.one*.15f,color,false).transform;
            body=Shapes.Make("Body",PrimitiveType.Capsule,transform,Vector3.zero,new Vector3(.35f,.35f,.25f),color,false).transform;
            if(IsOwner) foreach(var renderer in GetComponentsInChildren<Renderer>()) renderer.enabled=false;
        }

        void Update()
        {
            if(!IsSpawned) return;
            if(IsOwner && LocalRig.Instance != null && Time.unscaledTime>=nextPose)
            {
                nextPose=Time.unscaledTime+.0333f;
                var rig=LocalRig.Instance;
                PoseServerRpc(rig.Head.position,rig.Head.rotation,rig.Left.position,rig.Right.position);
            }
            if(headVisual==null) return;
            headVisual.position=Vector3.Lerp(headVisual.position,head.Value, .5f);
            headVisual.rotation=headRotation.Value;
            leftVisual.position=Vector3.Lerp(leftVisual.position,left.Value,.5f);
            rightVisual.position=Vector3.Lerp(rightVisual.position,right.Value,.5f);
            body.position=head.Value-Vector3.up*.45f;
        }

        static bool Valid(Vector3 v) => float.IsFinite(v.x) && float.IsFinite(v.y) && float.IsFinite(v.z) && v.sqrMagnitude<10000;

        [ServerRpc(Delivery=RpcDelivery.Unreliable)]
        void PoseServerRpc(Vector3 h,Quaternion rotation,Vector3 l,Vector3 r)
        {
            if(!Valid(h)||!Valid(l)||!Valid(r)||(l-h).sqrMagnitude>9||(r-h).sqrMagnitude>9) return;
            float q=rotation.x*rotation.x+rotation.y*rotation.y+rotation.z*rotation.z+rotation.w*rotation.w;
            if(!float.IsFinite(q)||q<.5f||q>1.5f) return;
            head.Value=h; headRotation.Value=rotation.normalized; left.Value=l; right.Value=r;
        }

        public void Spawn(int kind) { if(IsOwner && IsSpawned) SpawnServerRpc(kind); }

        [ServerRpc]
        void SpawnServerRpc(int kind)
        {
            if(Time.unscaledTime<nextAction || SharedThing.Count>=32 || kind<0 || kind>2) return;
            nextAction=Time.unscaledTime+.4f;
            var room=Room.Instance;
            var prefab=kind==0 ? room.bongoPrefab : kind==1 ? room.cubePrefab : room.ballPrefab;
            Vector3 forward=headRotation.Value*Vector3.forward;
            forward.y=0;
            var p=head.Value+forward.normalized*1.5f;
            p.y=Mathf.Max(.8f,p.y);
            Instantiate(prefab,p,Quaternion.identity).GetComponent<NetworkObject>().Spawn();
        }

        public void Clear() { if(IsOwner) ClearServerRpc(); }
        public void RemoveBongo() { if(IsOwner) RemoveBongoServerRpc(); }
        [ServerRpc]
        void RemoveBongoServerRpc()
        {
            if(Time.unscaledTime<nextAction) return;
            nextAction=Time.unscaledTime+.3f;
            SharedThing nearest=null;
            float distance=36;
            foreach(var thing in FindObjectsByType<SharedThing>(FindObjectsSortMode.None))
            {
                float d=(thing.transform.position-head.Value).sqrMagnitude;
                if(thing.IsSpawned && thing.kind==0 && d<distance){nearest=thing;distance=d;}
            }
            if(nearest!=null) nearest.NetworkObject.Despawn();
        }
        [ServerRpc]
        void ClearServerRpc()
        {
            // Only the room creator can clear everybody's creations.
            if(OwnerClientId!=NetworkManager.ServerClientId) return;
            foreach(var thing in FindObjectsByType<SharedThing>(FindObjectsSortMode.None))
                if(thing.IsSpawned) thing.NetworkObject.Despawn();
        }

        public void Interact(SharedThing target,int action,bool isLeft,int part=0)
        {
            if(IsOwner && target!=null && target.IsSpawned)
                InteractServerRpc(new NetworkObjectReference(target.NetworkObject),action,isLeft,part);
        }

        [ServerRpc]
        void InteractServerRpc(NetworkObjectReference reference,int action,bool isLeft,int part)
        {
            if(!reference.TryGet(out var obj)) return;
            var thing=obj.GetComponent<SharedThing>();
            if(thing==null) return;
            // Release is always permitted for the client's own held object.
            if(action==2) { thing.Release(OwnerClientId,isLeft); return; }
            if((thing.transform.position-Hand(isLeft)).sqrMagnitude>6.25f) return;
            if(action==0) thing.Punch(OwnerClientId,isLeft);
            else if(action==1) thing.Grab(this,isLeft,Mathf.Clamp(part,0,3));
            else if(action==3 && OwnerClientId==NetworkManager.ServerClientId) thing.NetworkObject.Despawn();
        }
    }
}
