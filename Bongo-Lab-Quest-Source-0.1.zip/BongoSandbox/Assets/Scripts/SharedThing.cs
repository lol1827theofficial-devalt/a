using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

namespace BongoSandbox
{
    public sealed class SharedThing : NetworkBehaviour
    {
        public int kind; // 0 Bongo, 1 block, 2 ball
        public static int Count;
        readonly NetworkVariable<int> health = new(3);
        readonly NetworkVariable<int> detached = new(0);
        Rigidbody physicsBody;
        Transform model;
        readonly List<Transform> parts=new();
        readonly Dictionary<ulong,float> hitTimes=new();
        Avatar holder;
        bool holderLeft;
        int heldPart;
        Vector3 offset, initialHand;
        float expires;
        int seenHealth=3,seenParts;
        bool counted;
        public bool Dead => health.Value<=0;

        public override void OnNetworkSpawn()
        {
            physicsBody=GetComponent<Rigidbody>();
            physicsBody.isKinematic=!IsServer;
            model=new GameObject("Model").transform;
            model.SetParent(transform,false);
            if(kind==0) BuildBongo();
            else Shapes.Make("Toy",kind==1?PrimitiveType.Cube:PrimitiveType.Sphere,model,Vector3.zero,Vector3.one*.5f,
                kind==1?new Color(.95f,.55f,.15f):new Color(.4f,.85f,.4f),false);
            seenHealth=health.Value;
            seenParts=detached.Value;
            ApplyState();
            if(IsServer) {Count++; counted=true;}
        }

        void BuildBongo()
        {
            var fur=new Color(.5f,.28f,.75f);
            parts.Add(Shapes.Make("Torso",PrimitiveType.Capsule,model,Vector3.zero,new Vector3(.5f,.45f,.32f),fur,false).transform);
            parts.Add(Shapes.Make("Head",PrimitiveType.Sphere,model,new Vector3(0,.65f,0),Vector3.one*.45f,fur,false).transform);
            parts.Add(Shapes.Make("Left arm",PrimitiveType.Capsule,model,new Vector3(-.42f,0,0),new Vector3(.19f,.4f,.19f),fur,false).transform);
            parts.Add(Shapes.Make("Right arm",PrimitiveType.Capsule,model,new Vector3(.42f,0,0),new Vector3(.19f,.4f,.19f),fur,false).transform);
            for(int i=0;i<2;i++)
            {
                var eye=Shapes.Make("Eye",PrimitiveType.Sphere,parts[1],new Vector3(i==0?-.2f:.2f,.08f,-.43f),Vector3.one*.16f,Color.white,false);
                Shapes.Make("Pupil",PrimitiveType.Sphere,eye.transform,new Vector3(0,0,-.45f),Vector3.one*.5f,Color.black,false);
            }
            Shapes.Label(model,"BONGO",new Vector3(0,1.15f,0),.065f);
        }

        public int PickPart(Vector3 point)
        {
            if(kind!=0) return 0;
            Vector3 p=transform.InverseTransformPoint(point);
            if(p.y>.38f) return 1;
            if(p.x<-.25f) return 2;
            if(p.x>.25f) return 3;
            return 0;
        }

        public void Punch(ulong player,bool left)
        {
            if(!IsServer || kind!=0 || Dead) return;
            ulong key=player*2+(left?0UL:1UL);
            if(hitTimes.TryGetValue(key,out float time)&&Time.time-time<.45f) return;
            hitTimes[key]=Time.time;
            health.Value=Mathf.Max(0,health.Value-1);
            if(Dead) Die();
        }

        public void Grab(Avatar avatar,bool left,int part)
        {
            if(!IsServer || Dead || (kind==0 && part>0 && (detached.Value&(1<<part))!=0)) return;
            if(holder!=null)
            {
                if(holder!=avatar || holderLeft!=left) return;
                return;
            }
            holder=avatar;holderLeft=left;heldPart=part;
            initialHand=avatar.Hand(left);
            offset=transform.position-initialHand;
            physicsBody.useGravity=false;
        }

        public void Release(ulong client,bool left)
        {
            if(holder==null || holder.OwnerClientId!=client || holderLeft!=left) return;
            holder=null;
            physicsBody.useGravity=true;
        }

        void FixedUpdate()
        {
            if(!IsServer || !IsSpawned) return;
            if(holder!=null && holder.IsSpawned)
            {
                Vector3 hand=holder.Hand(holderLeft);
                if(kind==0)
                {
                    // A dummy stays anchored while pulling; arms detach, head/torso defeat it.
                    if(Vector3.Distance(hand,initialHand)>.65f)
                    {
                        if(heldPart==2||heldPart==3) detached.Value|=1<<heldPart;
                        else {health.Value=0;Die();}
                        ScreamClientRpc();
                        holder=null;physicsBody.useGravity=true;
                    }
                }
                else
                    physicsBody.linearVelocity=Vector3.ClampMagnitude((hand+offset-transform.position)*14f,12);
            }
            else if(!physicsBody.useGravity) {holder=null;physicsBody.useGravity=true;}
            if(transform.position.y< -8 || (Dead && Time.time>expires)) NetworkObject.Despawn();
        }

        public void Kill()
        {
            if(!IsServer || kind!=0 || Dead) return;
            health.Value=0;Die();
        }

        void Die()
        {
            holder=null;
            physicsBody.useGravity=true;
            physicsBody.constraints=RigidbodyConstraints.None;
            physicsBody.AddTorque(new Vector3(2,0,1),ForceMode.Impulse);
            expires=Time.time+10;
        }

        void Update()
        {
            if(!IsSpawned || model==null) return;
            if(seenHealth!=health.Value || seenParts!=detached.Value)
            {
                bool hurt=health.Value<seenHealth;
                bool died=health.Value==0 && seenHealth>0;
                bool lost=detached.Value!=seenParts;
                if(hurt&&Room.Blood) Debris(new Color(.65f,.04f,.08f),8,.035f);
                if((died||lost)&&Room.Bones) Debris(new Color(.95f,.9f,.7f),died?8:2,.1f);
                seenHealth=health.Value;seenParts=detached.Value;
                ApplyState();
            }
        }

        void ApplyState()
        {
            if(kind!=0) return;
            for(int i=1;i<parts.Count;i++) parts[i].gameObject.SetActive((detached.Value&(1<<i))==0);
            if(Dead) model.localRotation=Quaternion.Euler(0,0,15);
        }

        void Debris(Color color,int count,float size)
        {
            for(int i=0;i<count;i++)
            {
                var item=Shapes.Make("Cartoon effect",PrimitiveType.Capsule,null,
                    transform.position+Random.insideUnitSphere*.3f,new Vector3(size,size*2,size),color);
                item.layer=2;
                var rb=item.AddComponent<Rigidbody>();
                rb.linearVelocity=Random.onUnitSphere*2+Vector3.up*2;
                rb.angularVelocity=Random.onUnitSphere*5;
                Destroy(item,2.5f);
            }
        }

        [ClientRpc]
        void ScreamClientRpc()
        {
            if(!Room.Sounds) return;
            // Original synthesized cartoon yelp; no copied audio asset.
            const int rate=22050;
            float[] samples=new float[rate/3];
            float phase=0;
            for(int i=0;i<samples.Length;i++)
            {
                float t=(float)i/samples.Length;
                phase+=2*Mathf.PI*(500+400*Mathf.Sin(t*3))/rate;
                samples[i]=Mathf.Sin(phase)*Mathf.Sin(t*Mathf.PI)*.16f;
            }
            var clip=AudioClip.Create("Bongo yelp",samples.Length,1,rate,false);
            clip.SetData(samples,0);
            AudioSource.PlayClipAtPoint(clip,transform.position,.5f);
            Destroy(clip,1);
        }

        public override void OnNetworkDespawn()
        {
            if(counted){Count=Mathf.Max(0,Count-1);counted=false;}
            if(model!=null) Destroy(model.gameObject);
        }
    }

    public sealed class Crusher : MonoBehaviour
    {
        float next;
        void Update()
        {
            if(Room.Instance==null || !Room.Instance.Manager.IsServer || Time.time<next) return;
            next=Time.time+.2f;
            foreach(var collider in Physics.OverlapBox(transform.position+Vector3.up*.8f,new Vector3(1.5f,1,1.5f)))
                collider.GetComponentInParent<SharedThing>()?.Kill();
        }
    }
}
