using UnityEngine;
using UnityEngine.XR;
using UnityEngine.InputSystem;

namespace BongoSandbox
{
    public sealed class LocalRig : MonoBehaviour
    {
        public static LocalRig Instance;
        public Transform Head,Left,Right;
        CharacterController body;
        UnityEngine.XR.InputDevice leftDevice,rightDevice,headDevice;
        Vector3 previousLeft,previousRight,velocity,leftAnchor,rightAnchor;
        bool leftAnchored,rightAnchored,leftGrip,rightGrip;
        SharedThing leftHeld,rightHeld;
        float nextHitLeft,nextHitRight,yaw,pitch;
        LineRenderer ray;
        bool tracking;

        void Awake()
        {
            Instance=this;
            transform.position=new Vector3(0,.1f,-3);
            body=gameObject.AddComponent<CharacterController>();
            body.radius=.22f;body.height=1.5f;body.center=Vector3.up*.8f;body.stepOffset=.25f;
            Head=new GameObject("Head camera").transform;
            Head.SetParent(transform,false);
            Head.localPosition=Vector3.up*1.6f;
            var camera=Head.gameObject.AddComponent<Camera>();
            camera.nearClipPlane=.06f;camera.farClipPlane=100;
            camera.backgroundColor=new Color(.09f,.15f,.24f);
            camera.clearFlags=CameraClearFlags.SolidColor;
            Head.gameObject.tag="MainCamera";
            Head.gameObject.AddComponent<AudioListener>();
            Left=Shapes.Make("Local left hand",PrimitiveType.Sphere,transform,new Vector3(-.3f,1.1f,.4f),Vector3.one*.14f,new Color(.2f,.8f,1),false).transform;
            Right=Shapes.Make("Local right hand",PrimitiveType.Sphere,transform,new Vector3(.3f,1.1f,.4f),Vector3.one*.14f,new Color(.2f,.8f,1),false).transform;
            ray=Right.gameObject.AddComponent<LineRenderer>();
            ray.positionCount=2;ray.startWidth=.006f;ray.endWidth=.002f;
            ray.material=new Material(Shader.Find("Sprites/Default"));
            ray.startColor=Color.cyan;ray.endColor=Color.white;
            previousLeft=Left.position;previousRight=Right.position;
        }

        void Update()
        {
            headDevice=InputDevices.GetDeviceAtXRNode(XRNode.Head);
            leftDevice=InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
            rightDevice=InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
            tracking=headDevice.isValid;
            bool lg=false,rg=false,trigger=false;
            if(tracking)
            {
                Track(headDevice,Head);Track(leftDevice,Left);Track(rightDevice,Right);
                leftDevice.TryGetFeatureValue(CommonUsages.gripButton,out lg);
                rightDevice.TryGetFeatureValue(CommonUsages.gripButton,out rg);
                rightDevice.TryGetFeatureValue(CommonUsages.triggerButton,out trigger);
                rightDevice.TryGetFeatureValue(CommonUsages.primary2DAxis,out Vector2 turn);
                if(Mathf.Abs(turn.x)>.7f && Time.time>nextTurn)
                {
                    transform.RotateAround(Head.position,Vector3.up,Mathf.Sign(turn.x)*30);
                    nextTurn=Time.time+.3f;
                    leftAnchored=rightAnchored=false;
                    previousLeft=Left.position;previousRight=Right.position;
                }
            }
            else Desktop(ref lg,ref rg,ref trigger);

            HandleHand(Left,lg,ref leftGrip,ref leftHeld,true,ref nextHitLeft,previousLeft);
            HandleHand(Right,rg,ref rightGrip,ref rightHeld,false,ref nextHitRight,previousRight);
            MoveArm(Left,lg,leftHeld,ref leftAnchored,ref leftAnchor);
            MoveArm(Right,rg,rightHeld,ref rightAnchored,ref rightAnchor);
            Vector3 correction=Vector3.zero;int anchors=0;
            if(leftAnchored){correction+=leftAnchor-Left.position;anchors++;}
            if(rightAnchored){correction+=rightAnchor-Right.position;anchors++;}
            if(anchors>0)
            {
                correction=Vector3.ClampMagnitude(correction/anchors,.35f);
                body.Move(correction);
                velocity=Vector3.ClampMagnitude(correction/Mathf.Max(Time.deltaTime,.005f),5);
            }
            else
            {
                if(body.isGrounded && velocity.y<0) velocity.y=-1;
                velocity.y+=Physics.gravity.y*Time.deltaTime;
                velocity.x=Mathf.MoveTowards(velocity.x,0,Time.deltaTime*6);
                velocity.z=Mathf.MoveTowards(velocity.z,0,Time.deltaTime*6);
                body.Move(velocity*Time.deltaTime);
            }
            if(transform.position.y< -5) Respawn();
            PointAtBoard(trigger);
            previousLeft=Left.position;previousRight=Right.position;
        }

        float nextTurn;
        bool lastTrigger;
        void PointAtBoard(bool trigger)
        {
            Transform pointer=tracking?Right:Head;
            Vector3 start=pointer.position,forward=pointer.forward;
            ray.SetPosition(0,start);
            ray.SetPosition(1,start+forward*5);
            if(Physics.Raycast(start,forward,out var hit,5))
            {
                ray.SetPosition(1,hit.point);
                if(trigger&&!lastTrigger) hit.collider.GetComponent<SandboxButton>()?.Press();
            }
            lastTrigger=trigger;
        }

        static void Track(UnityEngine.XR.InputDevice device,Transform target)
        {
            if(device.TryGetFeatureValue(CommonUsages.devicePosition,out Vector3 p)) target.localPosition=p;
            if(device.TryGetFeatureValue(CommonUsages.deviceRotation,out Quaternion q)) target.localRotation=q;
        }

        void MoveArm(Transform hand,bool grip,SharedThing held,ref bool anchored,ref Vector3 anchor)
        {
            if(!grip||held!=null){anchored=false;return;}
            if(anchored)
            {
                if(Vector3.Distance(hand.position,anchor)>1.5f) anchored=false;
                return;
            }
            foreach(var c in Physics.OverlapSphere(hand.position,.11f))
            {
                if(c.GetComponentInParent<LocalRig>()!=null || c.GetComponentInParent<SharedThing>()!=null || c.GetComponent<SandboxButton>()!=null) continue;
                anchor=hand.position;anchored=true;break;
            }
        }

        void HandleHand(Transform hand,bool grip,ref bool wasGrip,ref SharedThing held,bool isLeft,ref float nextHit,Vector3 previous)
        {
            var avatar=Avatar.Local;
            if(avatar==null||!avatar.IsSpawned){wasGrip=grip;return;}
            if(!grip&&wasGrip&&held!=null){avatar.Interact(held,2,isLeft);held=null;}
            if(grip&&!wasGrip)
            {
                foreach(var c in Physics.OverlapSphere(hand.position,.25f))
                {
                    var thing=c.GetComponentInParent<SharedThing>();
                    if(thing==null||thing.Dead) continue;
                    held=thing;
                    avatar.Interact(thing,1,isLeft,thing.PickPart(hand.position));break;
                }
            }
            float speed=Vector3.Distance(hand.position,previous)/Mathf.Max(.005f,Time.deltaTime);
            if(!grip && speed>1.4f && Time.time>=nextHit)
            {
                foreach(var c in Physics.OverlapSphere(hand.position,.18f))
                {
                    var thing=c.GetComponentInParent<SharedThing>();
                    if(thing==null||thing.kind!=0||thing.Dead) continue;
                    avatar.Interact(thing,0,isLeft);
                    nextHit=Time.time+.45f;break;
                }
            }
            wasGrip=grip;
        }

        void Desktop(ref bool lg,ref bool rg,ref bool trigger)
        {
            var k=Keyboard.current;var mouse=Mouse.current;
            if(k==null) return;
            if(mouse!=null&&mouse.rightButton.isPressed)
            {
                Vector2 d=mouse.delta.ReadValue();
                yaw+=d.x*.15f;pitch=Mathf.Clamp(pitch-d.y*.15f,-75,75);
            }
            Head.localRotation=Quaternion.Euler(pitch,yaw,0);
            Head.localPosition=Vector3.up*1.6f;
            Left.position=Head.TransformPoint(new Vector3(-.25f,-.3f,.5f));
            Right.position=Head.TransformPoint(new Vector3(.25f,-.3f,.5f));
            Right.rotation=Left.rotation=Head.rotation;
            Vector3 input=new Vector3((k.dKey.isPressed?1:0)-(k.aKey.isPressed?1:0),0,(k.wKey.isPressed?1:0)-(k.sKey.isPressed?1:0));
            body.Move(Quaternion.Euler(0,yaw,0)*input.normalized*Time.deltaTime*3);
            if(k.spaceKey.wasPressedThisFrame&&body.isGrounded) velocity.y=4;
            lg=k.qKey.isPressed;rg=k.eKey.isPressed;
            trigger=mouse!=null&&mouse.leftButton.isPressed;
            if(k.digit1Key.wasPressedThisFrame) Avatar.Local?.Spawn(0);
            if(k.digit2Key.wasPressedThisFrame) Avatar.Local?.Spawn(1);
            if(k.digit3Key.wasPressedThisFrame) Avatar.Local?.Spawn(2);
            if(k.rKey.wasPressedThisFrame) Respawn();
            // Editor interaction probe: F punches the aimed dummy.
            if(Avatar.Local!=null&&Physics.Raycast(Head.position,Head.forward,out var hit,2.4f))
            {
                var thing=hit.collider.GetComponentInParent<SharedThing>();
                if(thing!=null&&k.fKey.wasPressedThisFrame) Avatar.Local.Interact(thing,0,false);
            }
        }

        public void Respawn()
        {
            if(leftHeld!=null) Avatar.Local?.Interact(leftHeld,2,true);
            if(rightHeld!=null) Avatar.Local?.Interact(rightHeld,2,false);
            leftHeld=rightHeld=null;
            body.enabled=false;
            transform.position=new Vector3(0,.1f,-3);
            transform.rotation=Quaternion.identity;
            body.enabled=true;
            leftAnchored=rightAnchored=false;
            velocity=Vector3.zero;
            previousLeft=Left.position;previousRight=Right.position;
        }
    }
}
