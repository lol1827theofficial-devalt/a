using System;
using UnityEngine;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Services.Core;
using Unity.Services.Authentication;
using Unity.Services.Relay;

namespace BongoSandbox
{
    public sealed class Room : MonoBehaviour
    {
        public static Room Instance;
        public GameObject playerPrefab, bongoPrefab, cubePrefab, ballPrefab;
        public NetworkManager Manager { get; private set; }
        public string Status { get; private set; } = "Choose Create Room, or enter Jackson's code.";
        public string Code { get; private set; } = "";
        public bool Busy { get; private set; }
        public bool Connected => Manager != null && Manager.IsConnectedClient;
        public static bool Blood = false;
        public static bool Sounds = true;
        public static bool Bones = true;
        float joinStarted;

        void Awake()
        {
            Instance = this;
            Application.targetFrameRate = 72;
            var net = new GameObject("Networking");
            Manager = net.AddComponent<NetworkManager>();
            var transport = net.AddComponent<UnityTransport>();
            Manager.NetworkConfig.NetworkTransport = transport;
            Manager.NetworkConfig.PlayerPrefab = playerPrefab;
            Manager.NetworkConfig.EnableSceneManagement = false;
            Manager.NetworkConfig.ConnectionApproval = true;
            Manager.NetworkConfig.TickRate = 30;
            Manager.AddNetworkPrefab(playerPrefab);
            Manager.AddNetworkPrefab(bongoPrefab);
            Manager.AddNetworkPrefab(cubePrefab);
            Manager.AddNetworkPrefab(ballPrefab);
            Manager.ConnectionApprovalCallback += (request, response) =>
            {
                response.Approved = Manager.ConnectedClientsIds.Count < 2;
                response.CreatePlayerObject = response.Approved;
                response.Reason = response.Approved ? "" : "This private room has two players already.";
                response.Pending = false;
            };
            Manager.OnClientConnectedCallback += id =>
            {
                if (id == Manager.LocalClientId)
                {
                    Busy = false;
                    Status = "Connected. Spawn a Bongo at the sandbox board!";
                }
            };
            Manager.OnClientDisconnectCallback += id =>
            {
                if (id == Manager.LocalClientId || !Manager.IsHost)
                {
                    Busy = false;
                    Code = "";
                    Status = "Disconnected. " + Manager.DisconnectReason + " Create or join another room.";
                }
            };
            BuildMap();
            new GameObject("Local XR Rig").AddComponent<LocalRig>();
            new GameObject("Sandbox Board").AddComponent<SandboxBoard>();
        }

        void Update()
        {
            if (Busy && Manager.IsListening && !Connected && Time.unscaledTime - joinStarted > 20)
            {
                Manager.Shutdown();
                Busy = false;
                Status = "Connection timed out. Check the code and your internet connection.";
            }
        }

        public async void Connect(bool host, string joinCode = "")
        {
            if (Busy || Manager.IsListening || Manager.ShutdownInProgress) return;
            if (!host && (joinCode.Length < 4 || joinCode.Length > 12))
            { Status = "Enter the room code first."; return; }
            Busy = true;
            Status = "Connecting to private room service...";
            try
            {
                await UnityServices.InitializeAsync();
                if (!AuthenticationService.Instance.IsSignedIn)
                    await AuthenticationService.Instance.SignInAnonymouslyAsync();
                var transport = Manager.GetComponent<UnityTransport>();
                if (host)
                {
                    var allocation = await RelayService.Instance.CreateAllocationAsync(1);
                    var code = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);
                    transport.SetRelayServerData(AllocationUtils.ToRelayServerData(allocation, "dtls"));
                    if (!Manager.StartHost()) throw new Exception("Could not start host.");
                    Code = code;
                }
                else
                {
                    var allocation = await RelayService.Instance.JoinAllocationAsync(joinCode.Trim().ToUpperInvariant());
                    transport.SetRelayServerData(AllocationUtils.ToRelayServerData(allocation, "dtls"));
                    if (!Manager.StartClient()) throw new Exception("Could not start client.");
                    Status = "Joining room...";
                    Code = joinCode.Trim().ToUpperInvariant();
                }
                joinStarted = Time.unscaledTime;
            }
            catch (Exception e)
            {
                Busy = false;
                if (Manager.IsListening) Manager.Shutdown();
                Code = "";
                Status = "Room failed. Check Unity Services setup and internet. " + e.Message;
                Debug.LogException(e);
            }
        }

        public void LocalHost()
        {
            if (Busy || Manager.IsListening || Manager.ShutdownInProgress) return;
            Manager.GetComponent<UnityTransport>().SetConnectionData("127.0.0.1", 7777, "0.0.0.0");
            if (Manager.StartHost()) { Code = "OFFLINE"; Status = "Local practice. Internet room codes are disabled."; }
        }

        public void Leave()
        {
            if (Busy) return;
            Manager.Shutdown();
            Code = "";
            Status = "Room closed. Create or join another room.";
        }

        void BuildMap()
        {
            RenderSettings.ambientLight = new Color(.55f, .65f, .8f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(.09f, .15f, .24f);
            RenderSettings.fogDensity = .012f;
            Camera.main?.gameObject.SetActive(false);
            var light = new GameObject("Sun").AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.1f;
            light.transform.rotation = Quaternion.Euler(45, -25, 0);
            var root = new GameObject("Playground").transform;
            Shapes.Make("Ground", PrimitiveType.Cube, root, new Vector3(0,-.3f,0), new Vector3(32,.6f,32), new Color(.12f,.2f,.22f));
            for (int i=0;i<4;i++)
            {
                float a=i*90*Mathf.Deg2Rad;
                var wall = Shapes.Make("Boundary", PrimitiveType.Cube, root,
                    new Vector3(Mathf.Sin(a)*16,2,Mathf.Cos(a)*16), new Vector3(32,4,.4f), new Color(.15f,.22f,.32f));
                wall.transform.rotation = Quaternion.Euler(0,i*90,0);
            }
            for(int i=0;i<5;i++)
                Shapes.Make("Climbing steps", PrimitiveType.Cube, root, new Vector3(-6-i*.8f,.3f+i*.4f,3+i*1.2f),
                    new Vector3(2,.6f,2), new Color(.3f,.65f,.68f));
            Shapes.Make("Climb wall", PrimitiveType.Cube, root, new Vector3(-9,2.5f,0), new Vector3(.5f,5,6), new Color(.25f,.4f,.55f));
            var crusher = Shapes.Make("Bongo crusher",PrimitiveType.Cube,root,new Vector3(7,.1f,5),new Vector3(3,.2f,3),new Color(.6f,.15f,.22f));
            crusher.AddComponent<Crusher>();
            Shapes.Label(root,"BONGO CRUSHER\nPlace a dummy here",new Vector3(7,2,6.5f),.12f);
            Shapes.Label(root,"BONGO LAB\nPRIVATE SANDBOX",new Vector3(0,4.5f,8),.22f);
        }
    }
}
