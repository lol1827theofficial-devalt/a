using System;
using UnityEngine;

namespace BongoSandbox
{
    public sealed class SandboxButton : MonoBehaviour
    {
        public Action action;
        float next;
        public void Press()
        {
            if(Time.unscaledTime<next) return;
            next=Time.unscaledTime+.25f;
            action?.Invoke();
        }
    }

    public sealed class SandboxBoard : MonoBehaviour
    {
        TextMesh status,codeText,effects;
        string entered="";
        void Start()
        {
            transform.position=new Vector3(0,2,0);
            Shapes.Make("Board",PrimitiveType.Cube,transform,Vector3.zero,new Vector3(3.6f,3.9f,.1f),new Color(.035f,.065f,.12f));
            Shapes.Label(transform,"BONGO LAB  /  PRIVATE ROOMS",new Vector3(0,1.32f,-.08f),.065f);
            status=Shapes.Label(transform,"",new Vector3(0,1.04f,-.09f),.04f);
            codeText=Shapes.Label(transform,"",new Vector3(0,.8f,-.09f),.06f);
            Button("CREATE ROOM",new Vector3(-1,.5f,-.14f),new Vector3(1.2f,.28f,.08f),()=>Room.Instance.Connect(true));
            Button("JOIN CODE",new Vector3(.35f,.5f,-.14f),new Vector3(1.1f,.28f,.08f),()=>Room.Instance.Connect(false,entered));
            Button("LEAVE",new Vector3(1.3f,.5f,-.14f),new Vector3(.65f,.28f,.08f),()=>Room.Instance.Leave());
            const string keys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            for(int i=0;i<keys.Length;i++)
            {
                string key=keys[i].ToString();
                Button(key,new Vector3(-1.46f+(i%12)*.266f,.17f-(i/12)*.25f,-.14f),new Vector3(.23f,.21f,.08f),()=>{if(entered.Length<12)entered+=key;});
            }
            Button("BACK",new Vector3(-1.12f,-.62f,-.14f),new Vector3(.75f,.24f,.08f),()=>{if(entered.Length>0)entered=entered[..^1];});
            Button("PRACTICE",new Vector3(0,-.62f,-.14f),new Vector3(1.1f,.24f,.08f),()=>Room.Instance.LocalHost());
            Button("RESPAWN",new Vector3(1.14f,-.62f,-.14f),new Vector3(.95f,.24f,.08f),()=>LocalRig.Instance.Respawn());
            Button("SPAWN BONGO",new Vector3(-1.1f,-.96f,-.14f),new Vector3(1,.28f,.08f),()=>Avatar.Local?.Spawn(0));
            Button("BLOCK",new Vector3(0,-.96f,-.14f),new Vector3(.9f,.28f,.08f),()=>Avatar.Local?.Spawn(1));
            Button("BALL",new Vector3(1.1f,-.96f,-.14f),new Vector3(1,.28f,.08f),()=>Avatar.Local?.Spawn(2));
            Button("CLEAR (HOST)",new Vector3(-1.15f,-1.3f,-.14f),new Vector3(1.1f,.27f,.08f),()=>Avatar.Local?.Clear());
            Button("BLOOD",new Vector3(-.12f,-1.3f,-.14f),new Vector3(.8f,.27f,.08f),()=>Room.Blood=!Room.Blood);
            Button("REMOVE BONGO",new Vector3(1,-1.3f,-.14f),new Vector3(1.2f,.27f,.08f),()=>Avatar.Local?.RemoveBongo());
            Button("BONES ON/OFF",new Vector3(0,-1.78f,-.14f),new Vector3(1.3f,.27f,.08f),()=>Room.Bones=!Room.Bones);
            effects=Shapes.Label(transform,"",new Vector3(0,-1.53f,-.1f),.035f);

            var help=new GameObject("Instructions").transform;
            help.position=new Vector3(4,1.8f,0);
            Shapes.Make("Panel",PrimitiveType.Cube,help,Vector3.zero,new Vector3(3,2.3f,.1f),new Color(.06f,.12f,.16f));
            Shapes.Label(help,"WELCOME TO BONGO LAB\n\nRight trigger: select board buttons\nGrip near walls: climb / pull yourself\nGrip near toys: grab, release: throw\nFast open-hand swings: punch Bongo\nHold a dummy part + pull: detach\nThree punches: defeat the dummy\nCrusher pad: defeat the dummy\n\nOnly Bongos take damage.\nHost leaving closes the room.",new Vector3(0,0,-.09f),.06f);
        }

        void Button(string title,Vector3 position,Vector3 scale,Action action)
        {
            var go=Shapes.Make(title,PrimitiveType.Cube,transform,position,scale,new Color(.12f,.3f,.42f));
            go.AddComponent<SandboxButton>().action=action;
            var text=Shapes.Label(transform,title,position+Vector3.back*.055f,title.Length>5?.042f:.06f);
        }

        void Update()
        {
            var room=Room.Instance;
            if(room==null||status==null) return;
            string message=room.Status;
            if(message.Length>110)message=message[..110]+"...";
            if(message.Length>55)message=message.Insert(55,"\n");
            status.text=message;
            codeText.text=room.Connected?"ROOM: "+room.Code+"  |  Players: "+room.Manager.ConnectedClientsIds.Count:"CODE: "+entered;
            effects.text="Blood "+(Room.Blood?"ON":"OFF")+"   |   Cartoon bones "+(Room.Bones?"ON":"OFF")+"   |   32 shared toys maximum";
        }
    }
}
