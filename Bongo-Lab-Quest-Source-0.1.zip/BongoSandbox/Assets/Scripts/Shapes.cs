using UnityEngine;

namespace BongoSandbox
{
    public static class Shapes
    {
        public static Material Material(Color color)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            var material = new Material(shader);
            material.color = color;
            return material;
        }

        public static GameObject Make(string name, PrimitiveType type, Transform parent,
            Vector3 position, Vector3 scale, Color color, bool collision = true)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = Material(color);
            if (!collision)
            {
                var collider = go.GetComponent<Collider>();
                collider.enabled = false;
                Object.Destroy(collider);
            }
            return go;
        }

        public static TextMesh Label(Transform parent, string text, Vector3 position, float size = .065f)
        {
            var go = new GameObject("Label");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            var label = go.AddComponent<TextMesh>();
            label.text = text;
            label.characterSize = size;
            label.fontSize = 64;
            label.anchor = TextAnchor.MiddleCenter;
            label.alignment = TextAlignment.Center;
            label.color = Color.white;
            return label;
        }
    }
}
