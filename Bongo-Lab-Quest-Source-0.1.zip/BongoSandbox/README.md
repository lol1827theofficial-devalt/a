# Bongo Lab — Quest sandbox prototype 0.1

An original, two-player sandbox for Nolan and Jackson. This is a Unity source project, NOT a compiled APK. It has not passed Unity compilation or headset testing in the creation environment. No online service has been provisioned, and no two-headset connection has been verified. Do not treat it as a finished game.

## Included implementation

- Private two-player rooms using Unity Authentication, Relay and Netcode for GameObjects; on-headset room-code keypad.
- Local practice mode that starts a local host without Unity Services.
- Tracked head and controllers, grip-assisted arm movement and climbing, 30-degree snap turning, fall recovery and a respawn button.
- Shared, server-simulated blocks and balls; grip to hold, release to throw.
- Spawn Bongo, remove the nearest Bongo within six meters, and host-only clear-all. A 32-object limit bounds physics load.
- Bongo: three punches defeat it; pulling an arm triggers a synthesized cartoon yelp and hides that arm; pulling the head or torso defeats it. The crusher pad also defeats it.
- Defeated Bongos topple as a single physics body and disappear after ten seconds. This is not a full articulated ragdoll.
- Optional stylized red particles, default OFF, and optional goofy bone-shaped debris. These effects are local cosmetic effects, not synchronized physics objects.
- An original geometric playground and ape-shaped placeholder characters. No GILLA models, audio or code.

Not yet included: realistic injury rendering, real age verification, voice chat, persistent builds, accounts/profiles, full two-hand physics joints, host migration, a moving death machine, a published store listing, or store age-rating approval. This prototype has a static crusher pad. Only spawned Bongos take damage; player avatars do not.

## Open it

1. Extract the ZIP, then add this folder in Unity Hub. Use Unity **6000.0.85f1**.
2. For that editor, install **Android Build Support**, **Android SDK & NDK Tools**, and **OpenJDK** in Unity Hub. Android Studio's SDK alone is insufficient.
3. Open the project and let Package Manager finish. The manifest pins the project dependencies. Resolve any package/compiler errors before proceeding.
4. The editor should generate the playground on first import. If not, choose **Bongo Lab > 1 - Generate playground**. Open `Assets/Scenes/Sandbox.unity`.
5. Press Play and choose **PRACTICE** on the board for a local check.

## Configure headset support

1. Open **Edit > Project Settings > XR Plug-in Management**. In the **Android** tab enable **OpenXR**. If settings have not been generated, creating them here is required before the editor command works.
2. Choose **Bongo Lab > 2 - Configure Quest OpenXR**. Check **Oculus Touch Controller Profile** and **Meta Quest Support** in Android OpenXR settings. Run the OpenXR Project Validation fixes.
3. Use Android/ARM64 and IL2CPP. The generation command sets these along with OpenGLES3 and minimum Android API 32. Review the current Meta requirements before any store submission.
4. Choose **Bongo Lab > 3 - Build Quest APK**. It writes `Builds/BongoLab.apk` only if the actual build succeeds. The menu deliberately stops when Android support is unavailable.

## Enable private internet rooms

The code is present, but online rooms require a Unity project owned by you:

1. Link the project under **Project Settings > Services** to your Unity organization/project.
2. Enable anonymous Authentication and Relay/Multiplayer in that project's Unity Dashboard. Review the service's current quotas and billing before enabling it; nothing in this source automatically authorizes a purchase.
3. Build both headset copies from the same linked project and package versions. Do not put Unity dashboard secrets or admin credentials in the app.
4. Nolan chooses **CREATE ROOM**. Jackson enters the displayed code using the board and chooses **JOIN CODE**. The room accepts two players, including the host.
5. If the host leaves or suspends the app, the room ends; create a fresh room and code. Keep codes between you and Jackson; they are invitations, not verified identities.

Authentication uses anonymous per-installation identities. Private room codes do not verify age. There is no fake "verified 17+" badge or checkbox presented as verification.

## Controls

| Control | Action |
| --- | --- |
| Right hand aim + right trigger | Select a board button |
| Grip near scenery, move your hand | Pull yourself along / climb |
| Grip near a block or ball | Grab, then release to throw |
| Fast hand swing without grip | Punch a Bongo |
| Grip a Bongo part, pull at least 0.65 m | Pull effect / detach arm / defeat |
| Right stick sideways | Snap turn |
| RESPAWN | Return to the starting position |
| BLOOD / BONES ON/OFF | Toggle local cosmetic effects |

Desktop checks use WASD, right mouse drag to look, left mouse to click the aimed button, Space to jump, 1/2/3 to spawn, F to punch an aimed nearby dummy, Q/E for left/right grip, and R to respawn. The desktop controls are a test aid; the game is intended for Quest controllers.

## Install a successful APK build

Enable developer mode for your Quest account/device, connect the headset over USB, and accept its USB debugging prompt. Run `adb devices` and check that the device is authorized, then `adb install -r Builds/BongoLab.apk`. Launch it from Unknown Sources. Each player needs the same APK. An installable APK has NOT been supplied with this source ZIP.

## Validation still needed

This package passed file/JSON and C# syntax parsing checks using Roslyn, not Unity compilation. The installed editors could not be launched into the project successfully and Android playback modules were absent. Test controller tracking, startup XR, arm collisions, grab release/disconnect cleanup, latency, a late join after Bongo damage, simultaneous grabs, two-player capacity, incorrect/expired codes, host departure, and sustained headset performance before sharing a playable build.

Server checks cover object caps, spawn cooldowns, interaction distance, health transitions, grab ownership, and host-only clearing. This is prototype validation, not a production anti-cheat system. Client poses remain trusted inside bounded coordinates.

## Official references

- [Unity Relay with Netcode](https://docs.unity.com/en-us/mps-sdk/tutorials/relay-and-ngo)
- [Unity OpenXR project configuration](https://docs.unity3d.com/Packages/com.unity.xr.openxr@1.14/manual/project-configuration.html)
- [Meta Unity project setup](https://developers.meta.com/vr/documentation/unity/unity-tutorial-hello-world-manual-steps/)

## Source license

The original project code in this package is provided under the MIT license in `LICENSE.txt`. Unity and third-party packages retain their respective licenses and service terms.
